export const TAG_COLORS = {
  "default": "#4a8bfc",
  "secondary": "#32db64",
  "danger": "#f53d3d",
  "warn": "#ffc125",
  "gray": "#767676",
  "purple": "#7e60ff",
  "dark": "#222",
  "light": "#bcbcbc"
};
