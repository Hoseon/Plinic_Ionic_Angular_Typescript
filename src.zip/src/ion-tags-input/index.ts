/**
 * Created by hsuanlee on 2017/4/12.
 */
export { IonTagsInputModule } from './ion-tags-input.module'
export { IonTagsInput } from './ion-tags-input'
export { IonTag } from './ion-tag'
export { TAG_COLORS } from './colors'
