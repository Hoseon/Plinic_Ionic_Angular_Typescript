import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinChekCamera4Page } from './skin-chek-camera4';

@NgModule({
  declarations: [
    SkinChekCamera4Page,
  ],
  imports: [
    IonicPageModule.forChild(SkinChekCamera4Page),
  ],
})
export class SkinChekCamera4PageModule {}
