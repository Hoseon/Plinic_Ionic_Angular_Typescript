import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinChekConnectPage } from './skin-chek-connect'

@NgModule({
  declarations: [
    SkinChekConnectPage,
  ],
  imports: [
    IonicPageModule.forChild(SkinChekConnectPage),
  ],
})
export class SkinChekConnectPageModule {}
