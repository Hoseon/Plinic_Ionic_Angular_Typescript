import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinReadyPage } from './skin-ready';

@NgModule({
  declarations: [
    SkinReadyPage,
  ],
  imports: [
    IonicPageModule.forChild(SkinReadyPage),
  ],
})
export class SkinReadyPageModule {}
