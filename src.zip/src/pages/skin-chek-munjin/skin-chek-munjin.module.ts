import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinChekMunjinPage } from './skin-chek-munjin';

@NgModule({
  declarations: [
    SkinChekMunjinPage,
  ],
  imports: [
    IonicPageModule.forChild(SkinChekMunjinPage),
  ],
})
export class SkinChekMunjinPageModule {}
