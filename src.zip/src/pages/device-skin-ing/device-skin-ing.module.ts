import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DeviceSkinIngPage } from './device-skin-ing';

@NgModule({
  declarations: [
    DeviceSkinIngPage,
  ],
  imports: [
    IonicPageModule.forChild(DeviceSkinIngPage),
  ],
})
export class DeviceSkinIngPageModule {}
