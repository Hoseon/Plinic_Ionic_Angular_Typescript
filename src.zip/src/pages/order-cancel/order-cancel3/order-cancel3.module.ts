import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OrderCancel3Page } from './order-cancel3';

@NgModule({
  declarations: [
    OrderCancel3Page,
  ],
  imports: [
    IonicPageModule.forChild(OrderCancel3Page),
  ],
})
export class OrderCancel3PageModule {}
