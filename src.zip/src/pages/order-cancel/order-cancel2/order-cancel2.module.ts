import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OrderCancel2Page } from './order-cancel2';

@NgModule({
  declarations: [
    OrderCancel2Page,
  ],
  imports: [
    IonicPageModule.forChild(OrderCancel2Page),
  ],
})
export class OrderCancel2PageModule {}
