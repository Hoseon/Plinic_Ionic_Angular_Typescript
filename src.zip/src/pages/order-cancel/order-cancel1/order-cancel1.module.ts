import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OrderCancel1Page } from './order-cancel1';

@NgModule({
  declarations: [
    OrderCancel1Page,
  ],
  imports: [
    IonicPageModule.forChild(OrderCancel1Page),
  ],
})
export class OrderCancel1PageModule {}
