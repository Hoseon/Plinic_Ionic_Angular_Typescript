import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OrderCancel4Page } from './order-cancel4';

@NgModule({
  declarations: [
    OrderCancel4Page,
  ],
  imports: [
    IonicPageModule.forChild(OrderCancel4Page),
  ],
})
export class OrderCancel4PageModule {}
