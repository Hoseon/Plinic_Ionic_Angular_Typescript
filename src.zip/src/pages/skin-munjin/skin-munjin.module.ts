import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinMunjinPage } from './skin-munjin';

@NgModule({
  declarations: [
    SkinMunjinPage,
  ],
  imports: [
    IonicPageModule.forChild(SkinMunjinPage),
  ],
})
export class SkinMunjinPageModule {}
