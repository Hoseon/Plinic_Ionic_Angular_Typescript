import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinChekChartCopyPage } from './skin-chek-chart_copy';

@NgModule({
  declarations: [
    SkinChekChartCopyPage,
  ],
  imports: [
    IonicPageModule.forChild(SkinChekChartCopyPage),
  ],
})
export class SkinChekChartCopyPageModule {}
