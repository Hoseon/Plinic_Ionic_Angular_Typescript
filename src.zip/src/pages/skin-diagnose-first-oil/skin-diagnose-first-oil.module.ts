import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinDiagnoseFirstOilPage } from './skin-diagnose-first-oil';

@NgModule({
  declarations: [
    SkinDiagnoseFirstOilPage,
  ],
  imports: [
    IonicPageModule.forChild(SkinDiagnoseFirstOilPage),
  ],
})
export class SkinDiagnoseFirstOilPageModule {}
