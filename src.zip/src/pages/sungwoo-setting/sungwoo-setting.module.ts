import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SungwooSettingPage } from './sungwoo-setting';

@NgModule({
  declarations: [
    SungwooSettingPage,
  ],
  imports: [
    IonicPageModule.forChild(SungwooSettingPage),
  ],
})
export class SungwooSettingPageModule {}
