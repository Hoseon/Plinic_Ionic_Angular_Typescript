import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CareZoneMissionDeadlineEndPage } from './care-zone-mission-deadline-end';

@NgModule({
  declarations: [
    CareZoneMissionDeadlineEndPage,
  ],
  imports: [
    IonicPageModule.forChild(CareZoneMissionDeadlineEndPage),
  ],
})
export class CareZoneMissionDeadlineEndPageModule {}
