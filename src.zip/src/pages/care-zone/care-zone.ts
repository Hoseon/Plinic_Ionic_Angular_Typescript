import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, Loading, LoadingController, AlertController, ModalController } from 'ionic-angular';
import { CareZoneIngPage } from '../care-zone-ing/care-zone-ing';
import { ImagesProvider } from '../../providers/images/images';
import { CareZoneMissionIngPage } from '../care-zone-mission-ing/care-zone-mission-ing'
import { CareZoneMissionStartPage} from '../care-zone-mission-start/care-zone-mission-start'
import { ChalMissionStartPage } from '../chal-mission-start/chal-mission-start'
import { ChalMissionIngPage } from '../chal-mission-ing/chal-mission-ing'
import { CareZoneMissionDeadlineEndPage } from '../care-zone-mission-deadline-end/care-zone-mission-deadline-end'
import { AuthService } from '../../providers/auth-service';
import { AuthHttp, AuthModule, JwtHelper, tokenNotExpired } from 'angular2-jwt';
import { TimerObservable } from "rxjs/observable/TimerObservable";
import { Observable } from 'rxjs/Rx';
import { Device } from '@ionic-native/device';
import { MyinfoPage } from '../myinfo/myinfo';
import { ChalGuidePage } from '../chal-guide/chal-guide'
import { OrderDetailPage } from '../order-detail/order-detail';
// import { ImgLoader, ImageLoaderConfig } from 'ionic-image-loader';

@IonicPage()
@Component({
  selector: 'page-care-zone',
  templateUrl: 'care-zone.html',
})
export class CareZonePage {
  carezoneData: any;
  missionData: any;
  missionID: any;
  loading: Loading;
  userData: any;
  nickname: string;
  jwtHelper: JwtHelper = new JwtHelper();
  currentDate: Date = new Date();
  currentDay: any;
  today: any = new Date().toISOString();
  new: Array<boolean> = new Array<boolean>();
  recruiting: Array<boolean> = new Array<boolean>();
  mdchuchun: Array<boolean> = new Array<boolean>();
  ingmdchuchun: Array<boolean> = new Array<boolean>();
  ingapproaching: Array<boolean> = new Array<boolean>();
  approaching: Array<boolean> = new Array<boolean>();
  endrecruit: Array<boolean> = new Array<boolean>();
  missionCounter: Array<any> = new Array<any>();
  missionCounter2: Array<any> = new Array<any>();
  endcarezoneData: Array<any> = new Array<any>();
  d5: Array<any> = new Array<any>();
  d4: Array<any> = new Array<any>();
  d3: Array<any> = new Array<any>();
  d2: Array<any> = new Array<any>();
  d1: Array<any> = new Array<any>();
  endmission: Array<any> = new Array<any>();
  ingmissionCounter: any;
  thumb_image: any;
  ingBtn: any = false;
  profileimg_url: any;
  imagePath: any;
  from: any;
  origindday: any;
  dday: Array<any> = new Array<any>();
  percent: Array<any> = new Array<any>();
  //mission 정보
  carezone_id: Array<any> = new Array<any>();
  title: Array<any> = new Array<any>();
  maxmember: Array<any> = new Array<any>();
  body: Array<any> = new Array<any>();
  endcarezone_id: Array<any> = new Array<any>();
  endtitle: Array<any> = new Array<any>();
  endmaxmember: Array<any> = new Array<any>();
  endbody: Array<any> = new Array<any>();
  timeremaining: Array<any> = new Array<any>();
  displayTime: Array<any> = new Array<any>();
  tickFourth: any;
  tickThree: any;
  subscriptionFourth: any;
  subscriptionThree: any;
  missionmember: Array<any> = new Array<any>();
  memberRanking: Array<any> = new Array<any>();
  totaluserPoint: any;
  flag: Array<any> = new Array<any>();
  memberMaxDate: Array<any> = new Array<any>();
  maxDate: any;
  displayUseTimeList: Array<any> = new Array<any>();
  membercnt1 : Array<any> = new Array<any>();
  membercnt2 : Array<any> = new Array<any>();
  membercnt3: Array<any> = new Array<any>();


  tesgImages: Array<any> = new Array<any>();
  defaultImage: any = "assets/img/loading/loading.gif";





  constructor(
    public device : Device,
    public platform: Platform, 
    public nav: NavController,
    public navParams: NavParams, 
    private images: ImagesProvider,
    private loadingCtrl: LoadingController, 
    private alertCtrl: AlertController, 
    public authService: AuthService,
    public modalCtrl: ModalController,
    // private imageLoaderConfig: ImageLoaderConfig
  ) {
    this.platform.ready().then((readySource) => {
      // this.imageLoaderConfig.enableSpinner(true);
      this.androidBackButton();
      if (this.platform.is('android') || this.platform.is('core')) {
        this.currentDay = new Date().getDay();
        console.log(new Date().getDay());
        console.log(this.getCovertKoreaTime(new Date()));
      }
  
      if (this.platform.is('ios')) {
        this.currentDay = new Date().getDay();
      }
    });
  }

  ionViewDidLoad() {
    this.roadcareZone();  
  }

  ionViewWillEnter() {
    this.androidBackButton();
    this.loadItems();
  }

  ionViewWillLeave() {
  }

  ionViewDidLeave() {
    console.log("ionViewDidLeave Timer Clear!");
  }

  ionViewDidEnter(){
    console.log(this.totaluserPoint);
  }

  public loadItems() {
    this.authService.getUserStorage().then(items => {

      if (items.from === 'kakao' || items.from === 'google' || items.from === 'naver') {
        this.userData = {
          accessToken: items.accessToken,
          id: items.id,
          age_range: items.age_range,
          birthday: items.birthday,
          email: items.email,
          gender: items.gender,
          nickname: items.nickname,
          profile_image: items.profile_image,
          thumbnail_image: items.thumbnail_image,
          from: items.from,
          snsid: items.snsid
        };
        if (this.userData.thumbnail_image === "" || this.userData.thumbnail_image === undefined) {
          this.thumb_image = false;
        } else {
          this.thumb_image = true;
        }
        this.reloadUserPoint(this.userData.email);
        this.chkmission(this.userData.email);
      } else {
        this.userData = {
          accessToken: items.accessToken,
          id: items.id,
          age_range: items.age_range,
          birthday: items.birthday,
          email: this.jwtHelper.decodeToken(items).email,
          gender: items.gender,
          nickname: this.jwtHelper.decodeToken(items).name,
          profile_image: items.profile_image,
          thumbnail_image: items.thumbnail_image,
          from: 'plinic',
        };
        this.reloadUserPoint(this.userData.email);
        this.chkmission(this.userData.email);
        this.from = 'plinic';
      }
      this.profileimg_url = "http://plinic.cafe24app.com/userimages/";
      this.profileimg_url = this.profileimg_url.concat(this.userData.email + "?random+\=" + Math.random());
    });
  }



  public carezone_ing() {
    this.nav.push(CareZoneIngPage);
  }
  public mission_ing(id) {
    this.nav.push(CareZoneMissionIngPage, { _id: id });
  }
  public mission_start(carezone) {
    if (!this.missionID) {
      this.nav.push(ChalMissionStartPage,{ carezoneData: carezone }).then(() => {
        this.nav.getActive().onDidDismiss(data => {
          this.chkmission(this.userData.email);
        });
      });

    } else if (carezone._id === this.missionID) {
      this.nav.push(ChalMissionIngPage,{ carezoneData: carezone }).then(() => {
        this.nav.getActive().onDidDismiss(data => {
          this.chkmission(this.userData.email);
          console.log("ChalMissionIngPage 페이지 닫힘");
        });
      });

    } else {
      this.nav.push(ChalMissionStartPage,{ carezoneData: carezone }).then(() => {
        this.nav.getActive().onDidDismiss(data => {
          this.chkmission(this.userData.email);
          console.log("ChalMissionStartPage 페이지 닫힘222");
        });
      });

    }
  }

  public mission_deadline_end() {
    this.nav.push(CareZoneMissionDeadlineEndPage);
  }


  public diffdate(date1: Date = new Date(), date2: Date = new Date()) {
    return (date1.getTime() - date2.getTime()) / (1000 * 60 * 60 * 24)
  }

  //20190617 미션 참여자 인원 count
  public missionCount(id) {
  }

  missionMember(id) {
    this.images.getChallangeMember(id).subscribe(data => {
      if (data !== '') {
        this.missionmember = data;
        for(var k=0; k < data.length; k++) {
          this.memberMaxDate[k] = new Date(data[k].createdAt)
        };
        var max = Math.max.apply(null, this.memberMaxDate);
        this.maxDate = this.getCovertKoreaTime(new Date(max)).substr(0,10);
        var tempRank = 0;
        for (var i = 0; i < data.length; i++) {
          if(this.maxDate === this.getCovertKoreaTime(data[i].createdAt).substr(0,10)) {
            if(id==='5dc8ec79c2900f035ab2199d') {
              this.membercnt1[tempRank] = data[i].email;
            } else if (id==='5db93c8840a8cb311a047957') {
              this.membercnt2[tempRank] = data[i].email;
            } else if (id==='5db949ff40a8cb311a047958') { 
              this.membercnt3[tempRank] = data[i].email;
            }
            tempRank++;
          }
        }
      }
    });
  }

  public async roadcareZone() {
    this.images.carezoneRoad().subscribe(data => {

      if (data !== '') {
        for (let i = 0; i < data.length; i++) {
          if (this.currentDay === Number(data[i].day)) {
            this.flag[i] = "지금참여";
          } else {
            this.flag[i] = "진행중";
          }
          
          this.missionMember(data[i]._id);
          this.endcarezone_id[i] = data[i]._id;
          this.title[i] = data[i].title;
          this.maxmember[i] = data[i].maxmember;
          this.body[i] = data[i].body;
          this.timeremaining[i] = (new Date(data[i].endmission).getTime() - new Date().getTime()) / 1000;
          this.images.getChallangeMember(data[i]._id).subscribe(data3 => {
            if (data3 !== '') {
              this.missionmember[i] = data3;
            }
          });
          this.endmission[i] = new Date(data[i].endmission);
          this.endcarezoneData = data[i];
          this.tesgImages[i] = "https://plinic.s3.ap-northeast-2.amazonaws.com";
          this.tesgImages[i] = this.tesgImages[i] + "/" + data[i].filename;
        }
        this.carezoneData = data;

      } else {
        this.showError("이미지를 불러오지 못했습니다. 관리자에게 문의하세요.");
      }
    });

  }

  //20190617 미션 참여중인지 체크 하기
  public chkmission(email) {
    this.images.ChallengeChkMission(email).subscribe(data => {
      if (data.length <= 0) {
        this.missionID = "";
        this.missionData = "";
      } else if (data.length > 0) {
        for (let i = 0; i < data.length; i++) {
          if (!data[i].missioncomplete) { //완료하지 못한 미션이 있는 체크
            this.missionData = data[i];
            this.missionID = data[i].missionID;
          }
        }
      } else {
        console.log("이상한 값이 들어 왔을때 챌린지 참여 안한걸로");
        this.missionID="";
      }
    });

  }

  //20190618 진행 중인 미션 체크 하기
  public chkIngmission(email) {
    this.images.chkMission(email).subscribe(data => {
      if (data !== null) {
        this.missionData = data;
        this.ingBtn = true;
      } else if (data === '' || data === null || data === undefined) {
        this.ingBtn = false;
      } else {
        this.ingBtn = false;
        this.showError("이미지를 불러오지 못했습니다. 관리자에게 문의하세요.");
      }
    });
  }

  showLoading() {
    if (this.platform.is("ios") && this.device.model === 'iPhone7,2' || this.device.model === 'iPhone8,1' || this.device.model === 'iPhone9,1' || this.device.model === 'iPhone9,3' || this.device.model === 'iPhone10,1' || this.device.model === 'iPhone10,4') {
      let loading = this.loadingCtrl.create({
        spinner: 'hide',
        duration: 1000,
        cssClass: 'sk-rotating-plane_ios'
      });
      loading.present();
    } else if (this.platform.is("ios") && this.device.model === 'iPhone7,1' || this.device.model === 'iPhone8,2' || this.device.model === 'iPhone9,2' || this.device.model === 'iPhone9,4' || this.device.model === 'iPhone10,2' || this.device.model === 'iPhone10,5') {
      let loading = this.loadingCtrl.create({
        spinner: 'hide',
        duration: 1000,
        cssClass: 'sk-rotating-plane_ios_plus'
      });
      loading.present();
    } else if (this.platform.is("ios") && this.device.model === 'iPhone10,3' || this.device.model === 'iPhone10,6' || this.device.model === 'iPhone11,2' || this.device.model === 'iPhone11,8' || this.device.model === 'iPhone12,1' || this.device.model === 'iPhone12,3') {
      let loading = this.loadingCtrl.create({
        spinner: 'hide',
        duration: 1000,
        cssClass: 'sk-rotating-plane_ios_x'
      });
      loading.present();
    } else if (this.platform.is("ios") && this.device.model === 'iPhone11,4' || this.device.model === 'iPhone11,6' || this.device.model === 'iPhone12,5') {
      let loading = this.loadingCtrl.create({
        spinner: 'hide',
        duration: 1000,
        cssClass: 'sk-rotating-plane_ios_x_max'
      });
      loading.present();
    } else if (this.platform.is("ios") && this.device.model === 'iPhone11,4' || this.device.model === 'iPhone11,6' || this.device.model === 'iPhone12,8') {
      let loading = this.loadingCtrl.create({
        spinner: 'hide',
        duration: 1000,
        cssClass: 'sk-rotating-plane_ios_se2'
      });
      loading.present();
    } else {
      let loading = this.loadingCtrl.create({
        spinner: 'hide',
        duration: 1000,
        cssClass: 'sk-rotating-plane'
      });
      loading.present();
    }
  }

  showAlert(text) {
    let alert = this.alertCtrl.create({
      cssClass: 'push_alert',
      title: 'Plinic',
      message: text,
      buttons: ['OK']
    });
    alert.present();
  }

  showError(text) {
    let alert = this.alertCtrl.create({
      cssClass: 'push_alert',
      title: 'Plinic',
      message: text,
      buttons: ['OK']
    });
    alert.present();
  }

  timerTick() {
    this.subscriptionFourth = Observable.interval(1000).subscribe(x => {
      for (var i = 0; i < this.timeremaining.length; i++) {
        this.timeremaining[i]--;
        this.displayTime[i] = this.getSecondsAsDigitalClock(this.timeremaining[i]);
      }
      this.tickFourth--;
      this.tickThree--;
      let time = this.getSecondsAsDigitalClock(this.tickFourth);
      let time2 = this.getSecondsAsDigitalClock(this.tickThree);
    });
  }

  getSecondsAsDigitalClock(inputSeconds: number) {
    var sec_num = parseInt(inputSeconds.toString(), 10); // don't forget the second param
    var hours = Math.floor(sec_num / 3600);
    var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
    var seconds = sec_num - (hours * 3600) - (minutes * 60);
    var hoursString = '';
    var minutesString = '';
    var secondsString = '';
    hoursString = (hours < 10) ? "0" + hours : hours.toString();
    minutesString = (minutes < 10) ? "0" + minutes : minutes.toString();
    secondsString = (seconds < 10) ? "0" + seconds : seconds.toString();
    return hoursString + ':' + minutesString + ':' + secondsString;
    // console.log("displaytime : " + index + " : " + this.displayTime[index]);
  }

  addComma(data_value) { //숫자 세자리 마다 컴마 붙히기
    return Number(data_value).toLocaleString('en');
  }

  private reloadUserPoint(email) {
    // this.authService.reloadUserPointfromPlincShop(email).subscribe(data =>{
    //   // console.log("커뮤니티 사용자 포인트 : " + data)
    //   this.totaluserPoint = data.point;
    //   this.totaluserPoint = this.addComma(this.totaluserPoint);
    // });

    this.authService.reloadUserPointfromPlinc(email).subscribe(
      data => {
        this.totaluserPoint = JSON.stringify(data.totalPoint);
        this.totaluserPoint = this.addComma(this.totaluserPoint);
      },
      error => {
        console.log(
          "사용자 개인포인트 불러오기 에러발생 : " + JSON.stringify(error)
        );
      }
    );
  }

  public myinfo() {
    //2020-05-28 마이페이지 하단탭 제거
    let myModal = this.modalCtrl.create(MyinfoPage);
    myModal.onDidDismiss(data => {
      if(this.userData) {
        if (this.userData.from === 'kakao' || this.userData.from === 'google' || this.userData.from === 'naver') {
          this.reloadUserPoint(this.userData.email);
        }
        else {
          this.reloadUserPoint(this.userData.email);
        }
      }
      this.androidBackButton();
    });
    myModal.present();
  }


  //20200521 이용안내 페이지로 이동
  chalguide() {
    let modal = this.modalCtrl.create(ChalGuidePage);
    modal.onDidDismiss(data => {
    });
    modal.present();
  }

  getCovertKoreaTime(time) {
    return new Date(new Date(time).getTime() - new Date().getTimezoneOffset()*60000).toISOString()
  }

  getCovertKoreaTime2(time) {
    return new Date(new Date(time).getTime() - new Date().getTimezoneOffset()*60000);
  }

  getCovertKoreaTimeDay(time) {
    return new Date(new Date(time).getTime() - new Date().getTimezoneOffset()*60000).getDay();
  }

  getSecondsAsDigitalClock3(inputSeconds: number) {  // 분까지만 표시 하기 위한 함수
    var sec_num = parseInt(inputSeconds.toString(), 10);
    var hours = Math.floor(sec_num / 3600);
    var minutes2 = Math.floor((sec_num / 3600) * 60);
    var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
    var seconds = sec_num - (hours * 3600) - (minutes * 60);
    var hoursString = '';
    var minutesString = '';
    var minutesString2 = '';
    var secondsString = '';
    hoursString = (hours < 10) ? "0" + hours : hours.toString();
    minutesString = (minutes < 10) ? "0" + minutes : minutes.toString();
    minutesString2 = (minutes < 10) ? "0" + minutes2 : minutes2.toString();
    secondsString = (seconds < 10) ? "0" + seconds : seconds.toString();
    return minutesString2 + '분 ' + secondsString + '초';
  }

  //20190617 미션 참여자 인원 count //20200615 참여가 가능한날 인원이 5명이 넘을 경우 미션에 참여 하지 못하도록 한다
  missionCount2(id, date) : any {
    this.images.challangeCount2(id, date).subscribe(data => {
      if(Number(data) >= 10) {
        if(id === '5dc8ec79c2900f035ab2199d') {
          this.flag[0] = '참여마감';
        } else if (id === '5db93c8840a8cb311a047957'){
          this.flag[1] = '참여마감';
        } else if (id === '5db949ff40a8cb311a047958'){
          this.flag[2] = '참여마감';
        }
      } else {
        if(id === '5dc8ec79c2900f035ab2199d') {
          this.flag[0] = '지금참여';
        } else if (id === '5db93c8840a8cb311a047957'){
          this.flag[1] = '지금참여';
        } else if (id === '5db949ff40a8cb311a047958'){
          this.flag[2] = '지금참여';
        }
      }
    });
  }

  //20201125 안드로이드 백 버튼 처리
  androidBackButton() {
    if(this.platform.is('android')) {
      this.platform.registerBackButtonAction(()=>{
        this.nav.parent.select(0);
      });
    }
  }

  orderDetailPage() {
    this.nav.push(OrderDetailPage, {}).then(() => {
      this.nav.getActive().onDidDismiss(data => {
        console.log("배송 조회 페이지 닫힘");
      });
    });
  }

  ingCarezone(missionId) {
    this.nav.push(ChalMissionIngPage, { carezoeId: missionId }).then(() => {
      this.nav.getActive().onDidDismiss(data => {
        console.log("진행중인 챌린치 창이 닫힘");
        if (this.userData) {
          this.chkmission(this.userData.email);
        }
      });
    });
  }

  // onImageLoad(imgLoader: ImgLoader) {
  //   console.log("이미지 로드 완료");
  // }
}
