import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UseGuidePage } from './use-guide';

@NgModule({
  declarations: [
    UseGuidePage,
  ],
  imports: [
    IonicPageModule.forChild(UseGuidePage),
  ],
})
export class UseGuidePageModule {}
