import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SungwooCartPage } from './sungwoo-cart';

@NgModule({
  declarations: [
    SungwooCartPage,
  ],
  imports: [
    IonicPageModule.forChild(SungwooCartPage),
  ],
})
export class SungwooCartPageModule {}
