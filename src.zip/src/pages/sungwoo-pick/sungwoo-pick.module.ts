import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SungwooPickPage } from './sungwoo-pick';

@NgModule({
  declarations: [
    SungwooPickPage,
  ],
  imports: [
    IonicPageModule.forChild(SungwooPickPage),
  ],
})
export class SungwooPickPageModule {}
