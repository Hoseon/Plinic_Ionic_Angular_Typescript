import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MyinfoPage } from './myinfo';
import { StarRatingModule } from 'ionic3-star-rating';

@NgModule({
  declarations: [
    //MyinfoPage,
  ],
  imports: [
    //IonicPageModule.forChild(MyinfoPage),
  ],
})
export class MyinfoPageModule {}
