import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinChekCamera5Page } from './skin-chek-camera5';

@NgModule({
  declarations: [
    SkinChekCamera5Page,
  ],
  imports: [
    IonicPageModule.forChild(SkinChekCamera5Page),
  ],
})
export class SkinChekCamera5PageModule {}
