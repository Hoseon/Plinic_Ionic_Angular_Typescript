import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SungwooOrderPage } from './sungwoo-order';

@NgModule({
  declarations: [
    SungwooOrderPage,
  ],
  imports: [
    IonicPageModule.forChild(SungwooOrderPage),
  ],
})
export class SungwooOrderPageModule {}
