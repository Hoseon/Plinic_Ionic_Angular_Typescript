import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinDiagnoseOilPage } from './skin-diagnose-oil';

@NgModule({
  declarations: [
    SkinDiagnoseOilPage,
  ],
  imports: [
    IonicPageModule.forChild(SkinDiagnoseOilPage),
  ],
})
export class SkinDiagnoseOilPageModule {}
