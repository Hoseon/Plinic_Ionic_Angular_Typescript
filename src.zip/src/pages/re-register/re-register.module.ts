import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReRegisterPage } from './re-register';

@NgModule({
  declarations: [
    //ReRegisterPage,
  ],
  imports: [
    //IonicPageModule.forChild(ReRegisterPage),
  ],
})
export class ReRegisterPageModule {}
