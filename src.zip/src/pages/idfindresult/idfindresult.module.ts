import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IdfindresultPage } from './idfindresult';

@NgModule({
  declarations: [
    IdfindresultPage,
  ],
  imports: [
    IonicPageModule.forChild(IdfindresultPage),
  ],
})
export class IdfindresultPageModule {}
