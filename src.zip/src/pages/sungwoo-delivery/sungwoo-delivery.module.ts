import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SungwooDeliveryPage } from './sungwoo-delivery';

@NgModule({
  declarations: [
    SungwooDeliveryPage,
  ],
  imports: [
    IonicPageModule.forChild(SungwooDeliveryPage),
  ],
})
export class SungwooDeliveryPageModule {}
