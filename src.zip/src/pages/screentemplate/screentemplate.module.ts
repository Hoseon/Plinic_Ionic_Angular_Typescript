import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScreentemplatePage } from './screentemplate';

@NgModule({
  declarations: [
    ScreentemplatePage,
  ],
  imports: [
    IonicPageModule.forChild(ScreentemplatePage),
  ],
})
export class ScreentemplatePageModule {}
