import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegistercompletePage } from './registercomplete';

@NgModule({
  declarations: [
    //RegistercompletePage,
  ],
  imports: [
    //IonicPageModule.forChild(RegistercompletePage),
  ],
})
export class RegistercompletePageModule {}
