import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinChekCamera1Page } from './skin-chek-camera1'

@NgModule({
  declarations: [
    SkinChekCamera1Page,
  ],
  imports: [
    IonicPageModule.forChild(SkinChekCamera1Page),
  ],
})
export class SkinChekCamera1PageModule {}
