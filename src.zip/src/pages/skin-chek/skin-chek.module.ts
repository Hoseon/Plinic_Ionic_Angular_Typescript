import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinChekPage } from './skin-chek';

@NgModule({
  declarations: [
    SkinChekPage,
  ],
  imports: [
    IonicPageModule.forChild(SkinChekPage),
  ],
})
export class SkinChekPageModule {}
