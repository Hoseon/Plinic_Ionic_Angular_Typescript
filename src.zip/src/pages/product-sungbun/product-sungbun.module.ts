import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProductSungbunPage } from './product-sungbun';

@NgModule({
  declarations: [
    ProductSungbunPage,
  ],
  imports: [
    IonicPageModule.forChild(ProductSungbunPage),
  ],
})
export class ProductSungbunPageModule {}
