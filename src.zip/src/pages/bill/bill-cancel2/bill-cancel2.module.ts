import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BillCancel2Page } from './bill-cancel2';

@NgModule({
  declarations: [
    BillCancel2Page,
  ],
  imports: [
    IonicPageModule.forChild(BillCancel2Page),
  ],
})
export class BillCancel2PageModule {}
