import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BillCancel1Page } from './bill-cancel1';

@NgModule({
  declarations: [
    BillCancel1Page,
  ],
  imports: [
    IonicPageModule.forChild(BillCancel1Page),
  ],
})
export class BillCancel1PageModule {}
