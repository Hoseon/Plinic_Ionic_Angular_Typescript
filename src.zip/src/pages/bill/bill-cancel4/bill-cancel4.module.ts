import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BillCancel4Page } from './bill-cancel4';

@NgModule({
  declarations: [
    BillCancel4Page,
  ],
  imports: [
    IonicPageModule.forChild(BillCancel4Page),
  ],
})
export class BillCancel4PageModule {}
