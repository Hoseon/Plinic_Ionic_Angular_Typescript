import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BillCancel3Page } from './bill-cancel3';

@NgModule({
  declarations: [
    BillCancel3Page,
  ],
  imports: [
    IonicPageModule.forChild(BillCancel3Page),
  ],
})
export class BillCancel3PageModule {}
