import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinChekCamera3Page } from './skin-chek-camera3';

@NgModule({
  declarations: [
    SkinChekCamera3Page,
  ],
  imports: [
    IonicPageModule.forChild(SkinChekCamera3Page),
  ],
})
export class SkinChekCamera3PageModule {}
