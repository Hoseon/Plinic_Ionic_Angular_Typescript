import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinChekCamera2Page } from './skin-chek-camera2'

@NgModule({
  declarations: [
    SkinChekCamera2Page,
  ],
  imports: [
    IonicPageModule.forChild(SkinChekCamera2Page),
  ],
})
export class SkinChekCamera2PageModule {}
