import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkinChekConnect2Page } from './skin-chek-connect2';

@NgModule({
  declarations: [
    SkinChekConnect2Page,
  ],
  imports: [
    IonicPageModule.forChild(SkinChekConnect2Page),
  ],
})
export class SkinChekConnect2PageModule {}
