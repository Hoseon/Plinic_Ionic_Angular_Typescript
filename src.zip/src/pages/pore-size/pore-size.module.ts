import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PoreSizePage } from './pore-size';

@NgModule({
  declarations: [
    PoreSizePage,
  ],
  imports: [
    IonicPageModule.forChild(PoreSizePage),
  ],
})
export class PoreSizePageModule {}
