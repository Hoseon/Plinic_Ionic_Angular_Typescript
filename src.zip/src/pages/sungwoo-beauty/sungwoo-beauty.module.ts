import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SungwooBeautyPage } from './sungwoo-beauty';

@NgModule({
  declarations: [
    SungwooBeautyPage,
  ],
  imports: [
    IonicPageModule.forChild(SungwooBeautyPage),
  ],
})
export class SungwooBeautyPageModule {}
